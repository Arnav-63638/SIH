<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="/sih/Css/signup.css">

    <script type="text/javascript">
        function passupd(img)
        {
            document.getElementById("result").value+=img;
            document.getElementById("image").style.backgroundColor = 'Pink';
            setTimeout("ChangeColor2()",2000); 
        }
    </script>
    <style>
        #image{
        padding: 5px;        
    }
    </style>
</head>
<body>
    <section>
        <h3>
        <div id="left"><a href="/sih/loginpage.php" id="one">Login</a></div>
        <div id="right">Signup</div>
        </h3>
        <p>
            <form action="" method="post">
                <div >
                    <input class="form" type="email" name="email" id="name"  placeholder="&#9993; Email id" required>
                </div>
                <div >
                    <input class="form" type="text" name="name" id="name"  placeholder="&#9993; Name" required><br>
                </div>
                <div class="centre">
                    <input class="form" type="password" name="password" id="pass"  placeholder="&#128274; Create Password" required>
                </div>
                <br>
                <div id="rem">
                    <input type="checkbox" name="remember" id="rem" required> Remember me
                </div>
                <div>
                    <input type="submit" name="submit" id="submit" value="Signup">
                </div>
            </form>
            <center><input type="hidden" id="result"></center><br>
            <?php 
                $arr=array('1.jpg','2.jpg','3.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg','9.jpg','10.jpg');
                shuffle($arr);
                echo '<center>';
                for ($x = 0; $x <= 4; $x++)
                {
                    $va=substr($arr[$x],0,1);
                    echo '<button onClick="passupd('.$va.');"><img src="/sih/images/'.$arr[$x].'" height="60px" width="60px" id="image" ></button>&nbsp&nbsp&nbsp';
                }
                echo '<br><br>';
                for ($x = 5; $x <= 9; $x++)
                {
                    $va=substr($arr[$x],0,1);
                    echo '<button onClick="passupd('.$va.');"><img src="/sih/images/'.$arr[$x].'" height="60px" width="60px" id="image" ></button>&nbsp&nbsp&nbsp';
                }
                echo '</center>';
            ?>
            <br><br>
                


        <?php
        if(!empty($_POST))
        {
            
            $con=new mysqli('localhost','root','','sih') or die("Error".mysqli_error($con));

            $email=$_POST['email'];
            $name=$_POST['name'];
            $password=$_POST['password'];

            $sql1=mysqli_query($con,"Select * from user");
            $check=0;
            while ($row=mysqli_fetch_array($sql1))
            {
                $emaile=$row['email'];
                if ($emaile == $email)
                {
                    $check++;
                }
            }
            if ($check == 0)
            {
                $sql="insert into user set email='$email', name='$name', password='$password'";
                if(mysqli_query($con,$sql))
                {
                    echo "<script>alert('you have successfully singup');</script>";
                }
            }
            else
            {
                echo "<script>alert('This email id is already exist please try with other');</script>";
            }
        }
        ?>       
        </p>
    </section>
</body>
</html>