<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="/sih/Css/Loginpage.css">
</head>
<body>
    <section>
        <h3>
        <div id="left">Login</div>
        <div id="right"><a href="/sih/signup.php" id="one">Signup</a></div>
        </h3>
        <p>
            <form action="" method="post">
                <div class="centre" >
                    <input class="form" type="email" name="email" id="name"  placeholder="&#9993; Email id">
                </div>
                <div class="centre">
                    <input class="form" type="password" name="password" id="pass"  placeholder="&#128274; Password">
                </div>
                <div id="rem">
                    <input type="checkbox" name="remember" id="rem">
                    <label for="rem"> Remember me</label> 
                    <a href="forgot.html" id="forgot" target="_blank">Forgot password</a>
                </div>
                <div>
                    <input type="submit" name="submit" id="submit" value="Login">
                </div>
            </form>
        </p>
    </section>
<?php  
    if(!empty($_POST))
    {
        $con=new mysqli('localhost','root','','sih') or die("Error".mysqli_error($con));
        $emaili=$_POST['email'];
        $passwordi=$_POST['password'];
        $sql=mysqli_query($con,"Select * from user where email='$emaili'");
        $row=mysqli_fetch_array($sql);

        if ($row)
        {
            $email=$row['email'];
            $password=$row['password'];            

            if ($emaili==$email and $passwordi==$password)
            {
                header('location:/sih/dashboard.php');
            }
            else
            {
                echo '<center><div style="background-color: red; color: white; font-size: 130%; width: 180px; box-shadow: 0px 2px 5px black; margin-bottom: 30px;">Invalid Details</div></center>';
            }
        }
        else
        {
            echo '<center><div style="background-color: red; color: white; font-size: 130%; width: 180px; box-shadow: 0px 2px 5px black; margin-bottom: 30px;">Invalid Details</div></center>';
        }
    }
?>
</body>
</html>